﻿Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:Versao = '0.1.0'
$script:ContratoAtual = 1
$script:RaizPadrao = Split-Path -Parent $PSScriptRoot

foreach ($parte in 'Config', 'Elevacao', 'Seguranca', 'Remocao', 'Estado', 'MotorAjustes', 'Registro', 'Carregador', 'Saida', 'Cli') {
    . (Join-Path $PSScriptRoot "$parte.ps1")
}

function Get-TmdVersao {
    [CmdletBinding()]
    param()
    $script:Versao
}

Export-ModuleMember -Function @(
    'Get-TmdVersao'
    'Get-TmdCatalogo'
    'Get-TmdModulo'
    'Write-TmdModulos'
    'Write-TmdAlvos'
    'Format-TmdTamanho'
    'Invoke-TmdCli'
    'Get-TmdPastaConfig'
    'Get-TmdPastaDados'
    'Get-TmdListaProtecao'
    'Test-TmdCaminhoSeguro'
    'Remove-TmdItem'
    'Measure-TmdTamanho'
    'Get-TmdLixeira'
    'Clear-TmdLixeira'
    'Get-TmdUsoCpu'
    'Start-TmdMedidaCpu'
    'Initialize-TmdTipos'
    'Get-TmdHistorico'
    'Write-TmdOperacao'
    'New-TmdArquivoTemporario'
    'Remove-TmdArquivoTemporario'
    'Confirm-TmdExecucao'
    'Test-TmdAdministrador'
    'Request-TmdAdminAoAbrir'
    'Invoke-TmdAcaoModulo'
    'Write-TmdProgresso'
    'Undo-TmdAjusteComAdmin'
    'Test-TmdDesfazerPrecisaAdmin'
    'Invoke-TmdPrograma'
    'Set-TmdAjuste'
    'Invoke-TmdAcaoAjuste'
    'Get-TmdTextoIndireto'
    'Get-TmdIconePng'
    'Get-TmdAlvosParaTela'
    'Get-TmdIconePngPrimeiro'
    'Get-TmdCandidatosIcone'
    'Get-TmdIconesInstalados'
    'ConvertTo-TmdNomeSimples'
    'Restart-TmdExplorador'
    'Undo-TmdAjuste'
    'Get-TmdEstadoAjuste'
    'Test-TmdAjusteReversivel'
    'Get-TmdTextoDesfaz'
    'Update-TmdLeiturasLentas'
)
